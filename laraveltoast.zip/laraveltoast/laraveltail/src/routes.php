<?php

   Route::get('timezones/{timezone}', 
  'laraveltoast\laraveltail\LaravelTailController@index');